import AdminProductForm from '../AdminProductForm';

export default function AdminProductFormExample() {
  return <AdminProductForm />;
}
